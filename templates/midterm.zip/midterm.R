# Name:      Last, First
# Net ID: Insert your GW netID here
# (this is the part of your email before "@gwu.edu")

#############################################################
# HONOR CODE
#
# By typing an "x" in each of the brackets below (e.g. [x]),
# I promise that on this exam...
#
# [] I will not **offer** help to other classmates.
# [] I will not **accept** help from other classmates.
#############################################################

# Type your responses to each question below


# TRUE or FALSE

# --- 1)

# --- 2)

# --- 3)

# --- 4)


# Short Answer

# --- 1)

# --- 2)

# --- 3)

# --- 4)

# --- 5)

# --- 6)


# Mystery Functions

# --- 1)

# --- 2)


# Debugging

# --- 1)


# --- 2)


# Write Functions

# --- 1)


# --- 2)


# Bonus

library(TurtleGraphics)

# Part 1


# Part 2
